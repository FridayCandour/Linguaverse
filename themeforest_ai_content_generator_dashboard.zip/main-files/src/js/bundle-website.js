//Properjs
@@include('@@nodeRoot/node_modules/@popperjs/core/dist/umd/popper.min.js')
//simplebar
@@include('@@nodeRoot/node_modules/simplebar/dist/simplebar.min.js') 

//Swiper
@@include('@@nodeRoot/node_modules/swiper/swiper-bundle.min.js');

//Img Comparison Slider
@@include('@@nodeRoot/node_modules/img-comparison-slider/dist/index.js')

//typewriter
@@include('@@nodeRoot/node_modules/typewriter-effect/dist/core.js')

//masonry-layout
@@include('@@nodeRoot/node_modules/masonry-layout/dist/masonry.pkgd.min.js')

//Highlight
@@include('./vendors/highlight/highlight.min.js')
@@include('./vendors/highlight/languages/python.min.js')
@@include('./vendors/highlight/languages/javascript.min.js')
@@include('./vendors/highlight/languages/java.min.js')

// Functions
@@include('./functions/index.js')