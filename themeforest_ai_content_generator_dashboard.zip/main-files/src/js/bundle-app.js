//Properjs
@@include('@@nodeRoot/node_modules/@popperjs/core/dist/umd/popper.min.js')

//simplebar
@@include('@@nodeRoot/node_modules/simplebar/dist/simplebar.min.js') 

//ChoiceJS
@@include('@@nodeRoot/node_modules/choices.js/public/assets/scripts/choices.min.js')

//Dropzone
@@include('@@nodeRoot/node_modules/dropzone/dist/min/dropzone.min.js')

//Quill
@@include('@@nodeRoot/node_modules/quill/dist/quill.min.js')

//Photoswipe
@@include('@@nodeRoot/node_modules/photoswipe/dist/umd/photoswipe.umd.min.js')
@@include('@@nodeRoot/node_modules/photoswipe/dist/umd/photoswipe-lightbox.umd.min.js')

//Highlight
@@include('./vendors/highlight/highlight.min.js')
@@include('./vendors/highlight/languages/python.min.js')
@@include('./vendors/highlight/languages/javascript.min.js')
@@include('./vendors/highlight/languages/java.min.js')

// Functions
@@include('./functions/index.js')