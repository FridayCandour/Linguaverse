//Properjs
@@include('@@nodeRoot/node_modules/@popperjs/core/dist/umd/popper.min.js')

//simplebar
@@include('@@nodeRoot/node_modules/simplebar/dist/simplebar.min.js') 

//ChoiceJS
@@include('@@nodeRoot/node_modules/choices.js/public/assets/scripts/choices.min.js')

//Dropzone
@@include('@@nodeRoot/node_modules/dropzone/dist/min/dropzone.min.js')

// Functions
@@include('./functions/index.js')