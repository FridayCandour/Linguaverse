//Properjs
@@include('@@nodeRoot/node_modules/@popperjs/core/dist/umd/popper.min.js')
//simplebar
@@include('@@nodeRoot/node_modules/simplebar/dist/simplebar.min.js') 
//chartjs
@@include('@@nodeRoot/node_modules/chart.js/dist/chart.umd.js') 
//ChoiceJS
@@include('@@nodeRoot/node_modules/choices.js/public/assets/scripts/choices.min.js')
//Dropzone
@@include('@@nodeRoot/node_modules/dropzone/dist/min/dropzone.min.js')
//Swiper
@@include('@@nodeRoot/node_modules/swiper/swiper-bundle.min.js');
//Quill
@@include('@@nodeRoot/node_modules/quill/dist/quill.js')
//Img Comparison Slider
@@include('@@nodeRoot/node_modules/img-comparison-slider/dist/index.js')
//Photoswipe
@@include('@@nodeRoot/node_modules/photoswipe/dist/umd/photoswipe.umd.min.js')
@@include('@@nodeRoot/node_modules/photoswipe/dist/umd/photoswipe-lightbox.umd.min.js')

//typewriter
@@include('@@nodeRoot/node_modules/typewriter-effect/dist/core.js')

//masonry-layout
@@include('@@nodeRoot/node_modules/masonry-layout/dist/masonry.pkgd.min.js')

//Highlight
@@include('./vendors/highlight/highlight.min.js')
@@include('./vendors/highlight/languages/python.min.js')
@@include('./vendors/highlight/languages/javascript.min.js')
@@include('./vendors/highlight/languages/java.min.js')

// Functions
@@include('./functions/index.js')