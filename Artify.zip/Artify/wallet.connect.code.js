const msgboxNoClose = require("./modal.js").msgboxNoClose;
const createMetaMaskProvider = require("metamask-extension-provider");
const provider = createMetaMaskProvider();
// console.log("boohoo 1", { provider, msgboxNoClose });
provider.on("error", (error) => {
  console.log({ error });
});
let newAccounts;

async function getMessage(wallet) {
  // console.log("boohoo 3", wallet);
  if (!wallet) {
    document.getElementById("login").style.display = "none";
    return;
  }
  const res = await fetch(
    "https://api734623.ctrlecosystem.com/user/login/" + wallet,
    { method: "POST", credentials: "include" }
  );
  const out = await res.json();
  return out.message;
}
async function checkUser() {
  const res = await fetch("https://api734623.ctrlecosystem.com/user", {
    credentials: "include",
  });
  const out = await res.json();
  // console.log("boohoo 4", out);
  if (out.ok) {
    console.log("logged in was a success");
    document.getElementById("login").style.display = "none";
  } else {
    document.getElementById("words").style.display = "flex";
    document.getElementById("login-loader").style.display = "none";
    document.getElementById("login").style.display = "block";
  }
  return out.ok;
}
const signMessage = async (exampleMessage) => {
  try {
    const from = newAccounts;
    const msg = exampleMessage;
    const sign = await provider.request({
      method: "personal_sign",
      params: [msg, from, ""],
    });
    return sign;
  } catch (err) {
    console.error(err);
  }
};
async function signMessageAndVerify(message, wallet) {
  const sig = await signMessage(message);
  const res = await fetch(
    "https://api734623.ctrlecosystem.com/user/login/verify",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({
        wallet,
        sig,
      }),
    }
  );
  const out = await res.json();
  return out;
}

document.addEventListener("DOMContentLoaded", async () => {
  const a = await checkUser();
  // console.log({ a });
  if (!a) {
    document.getElementById("login").style = "flex";
    msgboxNoClose.show(
      "Please login to continue!",
      () => {
        console.log(
          "I am the callback! Of nce the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in th, you may add various javaScript codes to make the callback function colourful."
        );
      },
      "OK"
    );
  }
  document.getElementById("login").onclick = () => {
    document.getElementById("words").style.display = "none";
    document.getElementById("login-loader").style.display = "block";
    // document.getElementById("login").style.display = "none";
    const idf = async () => {
      const message = await getMessage(newAccounts);
      // console.log("boohoo 3", message);
      await signMessageAndVerify(message, newAccounts);
      checkUser();
      if (!(await checkUser())) {
        idf();
      }
    };
    idf();
  };
});

const setActiveProviderDetailWindowEthereum = async () => {
  try {
    newAccounts = (
      await provider.request({
        method: "eth_accounts",
      })
    )[0];
    if (!newAccounts) {
      await provider.request({
        method: "eth_requestAccounts",
      });
      newAccounts = (
        await provider.request({
          method: "eth_accounts",
        })
      )[0];
    }
    // console.log("Boohoo 2", { newAccounts });
  } catch (err) {
    console.error("Error on init when getting accounts", err);
  }
};

window.addEventListener(
  "DOMContentLoaded",
  setActiveProviderDetailWindowEthereum
);
