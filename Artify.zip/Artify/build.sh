#!/bin/bash

# Run Browserify to generate wallet.connect.js
browserify wallet.connect.code.js -o wallet.connect.js

# Run the JavaScript code
node -e "const { readFile, writeFile } = require('fs/promises'); \
          async function transformCode() { \
            try { \
              const code = await readFile('wallet.connect.js', { encoding: 'utf-8' }); \
              const transformedCode = code.replace('require(\'extension-port-stream\')', 'require(\'extension-port-stream\').default'); \
              await writeFile('wallet.connect.js', transformedCode); \
              console.log('Transformation completed successfully.'); \
            } catch (error) { \
              console.error('An error occurred while transforming the code:', error); \
            } \
          } \
          transformCode();"
