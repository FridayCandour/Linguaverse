chrome.runtime.onInstalled.addListener(() => {
  chrome.action.enable();
});

chrome.action.onClicked.addListener((tab) => {
  console.log("boohoo");
  // console.log({ tab });
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: () => {
      chrome.runtime.sendMessage({ action: "showPopup" });
    },
  });
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    files: ["wallet.connect.js"],
  });
});

chrome.contextMenus.removeAll(function () {
  chrome.contextMenus.create({
    id: "select",
    title: "Select this",
    contexts: ["all"],
    enabled: true,
  });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  const text = info.selectionText || "";
  const image = info.srcUrl || "";
  const model = "";
  const top = Math.round(tab.width / 2 - 425 + 50);
  const left = Math.round(tab.width / 2 - 200);
  const url =
    "index.html?" +
    encodeURI(
      "text=" +
        text +
        "&image=" +
        image +
        "&model=" +
        model +
        "&select=" +
        (!model ? true : false)
    );
  // console.log({ top, left, url, text: text, image: image });
  chrome.windows.create({
    focused: true,
    width: 400,
    height: 850,
    top,
    left,
    url,
    type: "popup",
  });
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "openPopup") {
    const top = Math.round(request.size.vw / 2 - 425 + 50);
    const left = Math.round(request.size.vw / 2 - 200);
    const url =
      "index.html?" +
      encodeURI(
        "text=" +
          (request.text || "") +
          "&image=" +
          (request.image || "") +
          "&model=" +
          request.model +
          "&select=" +
          (!request.model ? true : false)
      );
    chrome.windows.create({
      focused: true,
      width: 400,
      height: 850,
      top,
      left,
      url,
      type: "popup",
    });
  }
  // console.log("boohoo", request);
});

chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === "install") {
    const top = Math.round(700 - 425 + 50);
    const left = Math.round(660 - 200);
    const url = "index.html";
    chrome.windows.create({
      focused: true,
      width: 400,
      height: 850,
      top,
      left,
      url,
      type: "popup",
    });
  }
});
