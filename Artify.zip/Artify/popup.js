document.addEventListener("DOMContentLoaded", function () {
  let timeoutId = null;
  document.addEventListener("selectionchange", () => {
    if (timeoutId) {
      clearTimeout(timeoutId);
    }
    timeoutId = setTimeout(() => {
      const selectedText = window.getSelection().toString().trim();
      if (selectedText) {
        window.postMessage({
          action: "sendSelectedText",
          selectedText,
        });
      }
      timeoutId = null;
    }, 650);
  });
});
